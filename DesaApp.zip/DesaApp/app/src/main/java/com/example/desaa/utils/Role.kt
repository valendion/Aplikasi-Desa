package com.example.desaa.utils

enum class Role {
    Users,
    Headman,
    Backwoods
}