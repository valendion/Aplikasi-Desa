package com.example.desaa.ui.user.letter_submission_status

import androidx.lifecycle.ViewModel

class LetterSubmissionStatusViewModel: ViewModel() {

}