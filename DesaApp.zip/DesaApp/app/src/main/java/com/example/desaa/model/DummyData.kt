package com.example.desaa.model

data class DummyData(
    var name: String? = null,
    var nik: String? = null
)
