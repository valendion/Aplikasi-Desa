package com.example.desaa.utils

interface loading {
    fun showLoading()
    fun dismissLoading()
}