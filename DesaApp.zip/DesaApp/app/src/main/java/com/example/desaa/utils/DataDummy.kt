package com.example.desaa.utils

import androidx.lifecycle.MutableLiveData
import com.example.desaa.model.DummyData

object Data{
    val dataDummy = arrayListOf<DummyData>(
        DummyData("Dion", "3326160101810021"),
        DummyData("Ardi", "3326160101810021"),
        DummyData("Syahwan", "3326160101810021"),
        DummyData("Syahwan", "3326160101810021"),
    )
}
